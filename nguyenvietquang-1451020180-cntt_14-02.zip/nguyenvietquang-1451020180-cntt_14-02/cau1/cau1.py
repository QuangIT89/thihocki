n=int(input("Nhập vào một số:"))
d=dict()
for i in range(1,n+1):
    d[i]=i*i
print (d)

# nhập in ra màn hình tên của mình
NAME = str ( input ( "nhập tên:" ))
print ( "Tên tôi là:" , NAME )

# độ dài tên của mình
print("Ten co do dai la",len(NAME))


