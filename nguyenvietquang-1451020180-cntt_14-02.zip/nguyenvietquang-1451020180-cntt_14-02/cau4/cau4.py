values=input("Nhập vào dãy số: ")
q=values.split(",")
h=tuple(q)
print (q)
print (h)

print("nguyenvietquang1451020180")
my_string = "nguyenvietquang1451020180"
hovaten= my_string[0:15]
masinhvien = my_string[15:]
print("Họ và tên:",hovaten)
print("Mã sinh viên:",masinhvien)